# Changelog - Android SDK

## 8.5.3 (10/2016)

### Fixes

* Precaching crashes on Samsung devices

## 8.5.2 (10/2016)

### New

* Preloading static and video interstitials Endcards for better user experience

### Fixes

* Sample app issues when building from Android Studio 2.2
* AGPBI errors when building from Android Studio 2.2

## 8.5.1 (09/2016)

### New

* Added Video Interstitial support
* Added a callback to alert you when precaching videos is done
* Added a method to inform if videos are currently cached on the device

### Fixes

* Buffering issues in devices running Marshmallow+
* Video player issue in some low end devices
* Issue preventing a service to be closed

## 8.4.2 (08/2016)

### Fixes

Issue affecting DAU calculation

## 8.4.1 (07/2016)

### New

Added Hybrid Interstitials support

### Fixes

Possible crash when passing null message to Fyber Logger

## 8.3.2 (07/2016)

### New

* Enable changing user ID after starting the SDK
* Dropped support for Gingerbread (You'll still be able to compile your app, but no ads will be delivered)
* Improved user experience on browser redirection

### Fixes

* Custom SSL handling for Gingerbread
* Potential warnings when building with Android Studio 2.+
* Potential crash when handling expired cookies

## 8.3.1 (05/2016)

### Fixes

Possible crash when an app is updated from an SDK v7.x

## 8.3.0 (04/2016)

### New

Added Banner ads functionality

### Fixes

Possible crash when showing the user completion message in Rewarded Videos

## 8.1.6 (03/2016)

### Fixes

Possible issue when dismissing the Rewarded Video before it is loaded

## 8.1.5 (03/2016)

### Fixes

Issue with the automatic currency request after a Rewarded Video

## 8.1.4 (02/2016)

### Fixes

Possible issue with `Invalid Signature` response on VCS

## 8.1.3 (02/2016)

### New

Supporting Amazon devices

## 8.1.2 (02/2016)

### New

New API on `Fyber.Settings` exposing user ID

### Fixes

* Application is not blocked when video is suspended as soon as it starts
* Removing `Activity` leak after sdk start on specific devices
* Addressing potential crashes when:
  * precaching videos
  * showing a video

## 8.1.1 (01/2016)

### Fixes

* Issue retrieving Google Advertising ID in specific conditions

## 8.1.0 - (01/2016)

### New

* New: Allow publishers to enable HTTP for rewarded video

### Fixes

* Enabling Gingerbread to play HTTPS videos
* Bug fixes and performance improvements

## 8.0.1 (11/2015)

### Fixes

* Issue causing video files not being deleted from the device
* Excessive pre-caching bandwidth consumption

## 8.0.0 (09/2015)

### API Changes

* Rebranding (SponsorPaySDK -> Fyber SDK / SP -> FYB)
* Renamed products (BrandEngage -> Rewarded Videos…)
* Introduced fluent interface API through method chaining
* Introduces Requesters
    - New API for Interstitials
    - New API for Rewarded Videos
    - New API for Offer Wall
    - New API for Starting the SDK
    - New API for Virtual Currency
*  Introduces Reporters
    - New API to report Installs
    - New API to report Rewarded Actions

### Feature Removal

* Use of multiple AppIds
* Use of credentials token
* Overriding of the currency name through SDK’s API
* adapters.info and adapter.config for mediation

### Fixes

* Requesting videos from a background thread
* Possible leak broadcast receiver

### New

* New sample app shipped with the SDK
* Control over precaching functionality (delay the start) (only for Fyber Videos)
* Annotation processing for the mediation adapters

## 7.2.7 - (09/2015)

* Full support for Android Marshmallow
* Other minor improvements

## 7.2.6 - (08/2015)5

* Fixes potential issue
  * with webview cookies not being sent
  * with possible crash on user segments information being recreated

## 7.2.5 - (07/2015)

* Fixes a problem which caused unavailability of Rewarded Video ads under certain system locale

## 7.2.4 (07/2015)

* Fixed: Incorrect back button behavior for Rewarded Videos

## 7.2.3 (07/2015)

* Addresses a crash on SDK startup on some devices

## 7.2.0 (04/2015)

* Video pre-caching

## 7.1.1 (02/2015)

* Fixed: Potential timeout when requesting offers right after finishing previous engagement

## 7.1.0 (02/2015)

* Improved user experience for Rewarded Videos
* Other minor improvements and bug fixes

## 7.0.3 (01/2015)

* Improved interstitials mediation support
* Other minor improvements

## 7.0.2 (01/2015)

* Fixed: Issue when accessing web cookies

## 7.0.1 (11/2014)

* Improved Lollipop support

## 7.0.0 (11/2014)

* Full support for:
  * Ad placements
  * Multiple currencies
  * User segments
  * Fyber interstitial ads
* Several improvements and minor bug fixes

## 6.5.2

* Fix for an issue in server side configuration hash signature validation

## 6.5.1

* Dropped support for device below 2.3.3 (API level 10)
* Full support for server side configurations for mediation
* Minor improvements and bug fixes

## 6.1.2

* Full switch to [Google Advertising ID](https://developer.android.com/google/play-services/id.html) to ensure compliancy with [Google Play Developer Content Policies](https://play.google.com/about/developer-content-policy.html#ADID)
* Our SDK no longer accesses any other device identifiers such as MAC address or Android ID

## 6.1.0

* Mediation - added better logging of any issue while loading adapter related files
* Fixed potential bugs in BrandEngage:
* checking for Virtual Currency listener when performing the request
* ```SPBrandEngageRequestListener.onSPBrandEngageOffersNotAvailable``` is now called when a timeout occurs

## 6.0.0

* Added support for remote mediation configuration files
* Added support for Google Advertising ID (requires Google Play Services to be linked with your application)
* Improved performance in URL generation (not performed in the main thread anymore)
* Major internal refactoring

## 5.0.1

* Fixed issues in BrandEngage:
	* Leaked intent receiver is now unregistered
	* Potential issue with a video still playing when the back button was pressed

## 5.0.0

* Fixed potential issues with Android 4.2
* all WebView load url requests are now performed inside the UI thread
* Internal refactoring:
	* New and safer mechanism to handle WebView loading timeouts
	* New package declaration for the Offer Wall

## 4.0.1

* Fixed a potential crash in BrandEngage client adding error handling in when showing a dialog.

## 4.0.0

* Retired:
  * Mobile Banners
  * Mobile Unlock Offer Wall
  * Mobile Interstitial
* Reduced timeout for VCS polling after a successful mBE engagement
* Other minor bug fixes related to mBE error dialogs

##3.0.2

* Corrected issue that prevent Fyber URLs to be loaded correctly in some cases.

## 3.0.1

* Minor bug fix using thread safe client HTTP connection manager.

## 3.0.0

* New unified SDK adding support for Mobile BrandEngage<sup>&reg;</sup> to the existing Android SDK

## 2.0.0

* Added support for session handling
* Added support for Rewarded Actions.
* Other small improvements and bug fixes.

## 1.9.0

* Developers can now localize the name of an Unlock item.
* Added error handling for exceptions triggered by the non-availability of the Play Store or other Intent handlers necessary to follow an offer link.

## 1.8.2

* Added auto-generable user ID.
* Fixed a potential crash by adding check for null cookies on the Interstitial request.

## 1.8.1

* Added Fyber Unlock feature.

## 1.8.0

* Added more solid tracking.

## 1.7.0

* The vertical scrollbar on the mobile Offer Wall and Interstitial is hidden when the user is not scrolling, not taking any fixed amount of screen real state anymore.
* Added an HTTP Accept-Language header to the AsyncRequest class, based on the current locale and defaulting to English. This fixes an issue which could ocassionally prevent the Interstitial and Offer Banners to be returned in the right locale.
* Changed Interstitial activity to be floating. Interstitial size border width are now determined as a function of whether the host's device screen is bigger or smaller than a "tablet threshold". Actual width in pixels is calculated taking screen density into account.
* Other smaller improvements.

## 1.5.1

* Further refactored to avoid code duplication.

## 1.5.0

* Added Mobile Banners feature.
* Refactored the WebViewClient used to detect and act on the Fyber schema into its own class hierarchy to avoid code duplication.

## 1.4.0

* Last VCS transaction ID is now saved independently for each App ID / User ID pair.

## 1.3.1

* Fixed an issue which would prevent the right android_id from being fetched from the device.

## 1.3.0

* Unified Advertiser and Publisher SDKs into a single one.
* Removed references to Offer ID and Program ID. Now the advertiser callback is performed using App ID.
* App ID can now be alphanumeric.
* Modified the behavior of the advertiser callback, now it is always sent, albeit with a parameter which indicates whether it has been successful before for a given install.

## 1.2.0

* Added parameters android_id and mac_address (for which the Wi-Fi MAC address is fetched) to the advertiser callback request.

## 1.1.1

* Added the parameter `sdk_version=[release version]` to the advertiser callback request.

## 1.1.0

* Changed the default to expect a SPONSORPAY_PROGRAM_ID in the Manifest. The SDK will use this value to fill the program_id parameter in the callback URL.
* Added a switch that changes the parameter name in the callback URL to offer_id (`SponsorPayAdvertiser.setShouldUseOfferId(boolean value)` ). However in the manifest, the parameter is now called `SPONSORPAY_PROGRAM_ID` regardless of this setting in order to simplify the integration.
* The manifest parameter `SPONSORPAY_OFFER_ID` is no longer in use.
